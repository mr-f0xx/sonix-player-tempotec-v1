SONIX PLAYER - CUSTOM THEMES + ICON SETS
========================================

Extract this archive to the root of your microSD card. It will create:

  Themes/   - ready-made custom colour palettes (.ini files)
  Icons/    - four complete icon sets (gruvbox, rose-pine, dracula, catppuccin-mocha)
  custom-theme.ini - editable template for your own palette

On the V1, choose a palette in Settings -> Appearance -> Custom theme.
Choose matching artwork in Settings -> Appearance -> Icon set.

Files stay entirely on the card; no firmware modification is required.
More details: https://github.com/mr-f0xx/sonix-player-tempotec-v1/tree/main/sonix-player/examples
